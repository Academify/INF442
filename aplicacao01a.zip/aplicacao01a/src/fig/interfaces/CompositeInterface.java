package fig.interfaces;

/**
 * Interface para figuras compostas.
 * @author Vladimir Oliveira Di Iorio
 */
public interface CompositeInterface
extends FigInterface, FigListInterface {
		
}
