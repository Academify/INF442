package fig.interfaces;

/**
 * Interface geral para figuras.
 * @author Vladimir Oliveira Di Iorio
 */
public interface FigInterface {

}
